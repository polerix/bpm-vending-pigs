import SpriteKit

/// Protocol that all game levels conform to
protocol GameLevel {
    func setup(in scene: SKScene)
    func update(currentTime: TimeInterval, in scene: SKScene)
}

/// First level of the game: Factory enemies and intro boss
class Level0: GameLevel {

    private var spawnTimer: TimeInterval = 0
    private var bossSpawned = false

    func setup(in scene: SKScene) {
        // Background setup
        let bg = SKSpriteNode(imageNamed: "bg_factory")
        bg.size = scene.size
        bg.position = CGPoint(x: scene.size.width / 2, y: scene.size.height / 2)
        bg.zPosition = -1
        scene.addChild(bg)
    }

    func update(currentTime: TimeInterval, in scene: SKScene) {
        // Example: spawn logic placeholder
        // Custom spawn logic can go here
    }
}

/// Second level of the game: BaconJet enemies with fast-paced movement
class Level1: GameLevel {

    private var spawnTimer: TimeInterval = 0
    private var spawnInterval: TimeInterval = 1.0

    func setup(in scene: SKScene) {
        // Setup unique background for level 1
        let bg = SKSpriteNode(imageNamed: "bg_meatspace")
        bg.size = scene.size
        bg.position = CGPoint(x: scene.size.width / 2, y: scene.size.height / 2)
        bg.zPosition = -1
        scene.addChild(bg)
    }

    func update(currentTime: TimeInterval, in scene: SKScene) {
        // Increment spawn timer
        spawnTimer += 1.0 / 60.0

        // Spawn bacon jets on interval
        if spawnTimer >= spawnInterval {
            spawnTimer = 0
            spawnBaconJet(in: scene)
        }
    }

    private func spawnBaconJet(in scene: SKScene) {
        let baconJet = SKSpriteNode(imageNamed: "enemy_baconjet")
        baconJet.name = "enemy"
        baconJet.size = CGSize(width: 128, height: 96)
        baconJet.zPosition = 5

        // Random Y within safe bounds
        let y = CGFloat.random(in: 80...(scene.size.height - 80))
        baconJet.position = CGPoint(x: scene.size.width + baconJet.size.width / 2, y: y)

        // Set up physics body
        baconJet.physicsBody = SKPhysicsBody(texture: baconJet.texture!, size: baconJet.size)
        baconJet.physicsBody?.isDynamic = true
        baconJet.physicsBody?.categoryBitMask = PhysicsCategory.enemy
        baconJet.physicsBody?.contactTestBitMask = PhysicsCategory.projectile | PhysicsCategory.player
        baconJet.physicsBody?.collisionBitMask = PhysicsCategory.none

        scene.addChild(baconJet)

        // Fly across screen and disappear
        let move = SKAction.moveBy(x: -scene.size.width - baconJet.size.width, y: 0, duration: 4.0)
        let remove = SKAction.removeFromParent()
        baconJet.run(SKAction.sequence([move, remove]))
    }
}
