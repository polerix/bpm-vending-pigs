import SpriteKit
import AVFoundation

/// The main gameplay scene where all action occurs.
class GameScene: SKScene, SKPhysicsContactDelegate {

    // MARK: - Properties

    var player: Player!
    var hud: HUD!
    var backgroundMusic: AVAudioPlayer?

    var score = 0
    var meatLevel: CGFloat = 1.0

    var bossRef: Boss?

    var currentLevel: GameLevel!

    // MARK: - Scene Initialization

    override func didMove(to view: SKView) {
        backgroundColor = .black
        physicsWorld.gravity = .zero
        physicsWorld.contactDelegate = self

        setupPlayer()
        setupHUD()
        playMusic()

        // Start first level
        currentLevel = Level0()
        currentLevel.setup(in: self)
    }

    func setupPlayer() {
        player = Player()
        player.position = CGPoint(x: size.width * 0.1, y: size.height / 2)
        addChild(player)
    }

    func setupHUD() {
        hud = HUD()
        hud.position = .zero
        hud.zPosition = 100
        addChild(hud)

        hud.updateScore(to: score)
        hud.setMeatLevel(to: meatLevel)
        hud.setBossHealth(to: 1.0)
        hud.showBossHealth(false)
    }

    func playMusic() {
        if let url = Bundle.main.url(forResource: "bgm_greasefactory", withExtension: "mp3") {
            do {
                backgroundMusic = try AVAudioPlayer(contentsOf: url)
                backgroundMusic?.numberOfLoops = -1
                backgroundMusic?.play()
            } catch {
                print("❌ Error loading music: \(error)")
            }
        }
    }

    // MARK: - Player Input

    override func keyDown(with event: NSEvent) {
        switch event.keyCode {
        case 0x7E: player.move(direction: CGVector(dx: 0, dy: 1))    // ↑ Up
        case 0x7D: player.move(direction: CGVector(dx: 0, dy: -1))   // ↓ Down
        case 0x7B: player.move(direction: CGVector(dx: -1, dy: 0))   // ← Left
        case 0x7C: player.move(direction: CGVector(dx: 1, dy: 0))    // → Right
        case 0x31: player.shoot(scene: self)                         // ␣ Spacebar
        default: break
        }
    }

    // MARK: - Collision Handling

    func didBegin(_ contact: SKPhysicsContact) {
        let nodes = [contact.bodyA.node, contact.bodyB.node]

        if let projectile = nodes.first(where: { $0 is Projectile }) as? Projectile,
           let target = nodes.first(where: { $0 is Enemy || $0 is Boss }) {

            projectile.removeFromParent()

            if let enemy = target as? Enemy {
                enemy.explode()
            } else if let boss = target as? Boss {
                boss.takeDamage()
                let health = max(0.0, CGFloat(boss.health) / 10.0)
                hud.setBossHealth(to: health)

                if health <= 0.0 {
                    hud.showBossHealth(false)
                    advanceToNextLevel()
                }
            }

            score += 100
            meatLevel -= 0.05
            hud.updateScore(to: score)
            hud.setMeatLevel(to: meatLevel)
        }

        if let enemy = nodes.first(where: { $0 is Enemy || $0 is Boss }),
           let _ = nodes.first(where: { $0 is Player }) {
            enemy?.removeFromParent()
            player.removeFromParent()
            endGame()
        }
    }

    // MARK: - Per-Frame Update

    override func update(_ currentTime: TimeInterval) {
        player?.clampPosition(in: self)
        currentLevel?.update(currentTime: currentTime, in: self)
    }

    // MARK: - Level Control

    func advanceToNextLevel() {
        // Transition to Level1 after boss dies
        backgroundMusic?.stop()
        let newScene = GameScene(size: self.size)
        newScene.currentLevel = Level1()
        newScene.scaleMode = .resizeFill
        self.view?.presentScene(newScene, transition: .doorsOpenHorizontal(withDuration: 1.5))
    }

    // MARK: - Game Over

    func endGame() {
        backgroundMusic?.stop()
        let gameOver = GameOverScene(size: self.size)
        gameOver.scaleMode = .resizeFill
        self.view?.presentScene(gameOver, transition: .fade(withDuration: 1.2))
    }
}
