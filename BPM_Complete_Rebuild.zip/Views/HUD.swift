
import SpriteKit

class HUD: SKNode {
    override init() {
        super.init()
    }
    required init?(coder aDecoder: NSCoder) { super.init(coder: aDecoder) }
}
