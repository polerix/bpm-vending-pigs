
import SpriteKit

class Boss: SKSpriteNode {
    init() {
        let texture = SKTexture(imageNamed: "meat_demon")
        super.init(texture: texture, color: .clear, size: CGSize(width: 192, height: 192))
    }
    required init?(coder aDecoder: NSCoder) { super.init(coder: aDecoder) }
}
