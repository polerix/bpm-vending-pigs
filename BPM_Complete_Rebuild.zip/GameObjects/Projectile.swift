
import SpriteKit

class Projectile: SKSpriteNode {
    init() {
        let texture = SKTexture(imageNamed: "projectile_sausage")
        super.init(texture: texture, color: .clear, size: CGSize(width: 32, height: 16))
    }
    required init?(coder aDecoder: NSCoder) { super.init(coder: aDecoder) }
}
