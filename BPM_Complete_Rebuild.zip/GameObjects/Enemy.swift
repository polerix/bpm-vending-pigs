
import SpriteKit

class Enemy: SKSpriteNode {
    init() {
        let texture = SKTexture(imageNamed: "enemy_blob")
        super.init(texture: texture, color: .clear, size: CGSize(width: 64, height: 64))
    }
    required init?(coder aDecoder: NSCoder) { super.init(coder: aDecoder) }
}
