import SpriteKit

class Player: SKSpriteNode {
    var moveSpeed: CGFloat = 300.0

    init() {
        let texture = SKTexture(imageNamed: "porkborg_ship")
        super.init(texture: texture, color: .clear, size: CGSize(width: 96, height: 96))
        self.name = "player"
        self.zPosition = 10
        setUpPhysics()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    private func setUpPhysics() {
        self.physicsBody = SKPhysicsBody(texture: self.texture!, size: self.size)
        self.physicsBody?.isDynamic = true
        self.physicsBody?.categoryBitMask = PhysicsCategory.player
        self.physicsBody?.contactTestBitMask = PhysicsCategory.enemy | PhysicsCategory.projectile
        self.physicsBody?.collisionBitMask = 0
    }

    func move(direction: CGVector) {
        let dx = direction.dx * moveSpeed
        let dy = direction.dy * moveSpeed
        self.physicsBody?.velocity = CGVector(dx: dx, dy: dy)
    }

    func shoot(scene: SKScene) {
        let bullet = Projectile()
        bullet.position = self.position
        scene.addChild(bullet)
        bullet.fire()
    }
}