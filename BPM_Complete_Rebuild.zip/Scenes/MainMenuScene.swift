import SpriteKit

class MainMenuScene: SKScene {

    private var titleLabel: SKLabelNode?
    private var promptLabel: SKLabelNode?

    override func didMove(to view: SKView) {
        backgroundColor = .black

        let title = SKLabelNode(fontNamed: "Impact")
        title.text = "🧠 BROKEN PORK MACHINE"
        title.fontSize = 64
        title.fontColor = .systemPink
        title.zPosition = 10
        title.horizontalAlignmentMode = .center
        addChild(title)
        titleLabel = title

        let prompt = SKLabelNode(fontNamed: "Courier-Bold")
        prompt.text = "PRESS [ENTER] TO BEGIN"
        prompt.fontSize = 24
        prompt.fontColor = .white
        prompt.zPosition = 10
        prompt.horizontalAlignmentMode = .center
        addChild(prompt)
        promptLabel = prompt

        prompt.run(SKAction.repeatForever(SKAction.sequence([
            .fadeOut(withDuration: 0.8),
            .fadeIn(withDuration: 0.4)
        ])))
    }

    override func didChangeSize(_ oldSize: CGSize) {
        guard let title = titleLabel, let prompt = promptLabel else { return }
        guard size.width > 0, size.height > 0 else { return }

        title.position = CGPoint(x: size.width / 2, y: size.height * 0.6)
        prompt.position = CGPoint(x: size.width / 2, y: size.height * 0.4)
    }

    override func keyDown(with event: NSEvent) {
        if event.keyCode == 0x24 { // Enter
            let gameScene = GameScene(size: size)
            gameScene.scaleMode = .resizeFill
            view?.presentScene(gameScene, transition: .doorsOpenVertical(withDuration: 1.0))
        }
    }
}