
import SpriteKit

class CreditsScene: SKScene {
    override func didMove(to view: SKView) {
        backgroundColor = .blue
    }
}
