
import SpriteKit
import AVFoundation

class GameScene: SKScene, SKPhysicsContactDelegate {
    // Properties, setup, etc.
    override func didMove(to view: SKView) {
        backgroundColor = .black
    }
}
