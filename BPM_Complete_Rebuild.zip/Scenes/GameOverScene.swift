
import SpriteKit

class GameOverScene: SKScene {
    override func didMove(to view: SKView) {
        backgroundColor = .red
    }
}
