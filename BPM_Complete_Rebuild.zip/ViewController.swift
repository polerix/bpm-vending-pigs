
import Cocoa
import SpriteKit

class ViewController: NSViewController {
    @IBOutlet var skView: SKView!
    override func viewDidAppear() {
        super.viewDidAppear()
        if let window = view.window {
            window.toggleFullScreen(nil)
        }
        let scene = MainMenuScene(size: skView.bounds.size)
        scene.scaleMode = .resizeFill
        skView.presentScene(scene)
    }
}
