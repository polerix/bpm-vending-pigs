
import Cocoa

@main
class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        print("🐷 BPM Started")
    }
    func applicationWillTerminate(_ aNotification: Notification) {
        print("👋 Goodbye, bacon!")
    }
}
